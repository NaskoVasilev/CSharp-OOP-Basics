﻿using System;
using System.Collections.Generic;

namespace CustomList
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            SoftUniList<string> softUniList = new SoftUniList<string>();

       
        }
    }
}
