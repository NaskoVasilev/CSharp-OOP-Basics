﻿using System;
using System.Collections.Generic;

namespace ReadOnlyCollectionDemo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            
        }
    }
}
