﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Models.Characters
{
    public enum Faction
    {
        CSharp,
        Java
    }
}
